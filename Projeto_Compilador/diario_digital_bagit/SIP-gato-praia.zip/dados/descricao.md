Hoje senti-me como este gato
A pensar na vida, enquanto estou na praia. Algo que adoro!